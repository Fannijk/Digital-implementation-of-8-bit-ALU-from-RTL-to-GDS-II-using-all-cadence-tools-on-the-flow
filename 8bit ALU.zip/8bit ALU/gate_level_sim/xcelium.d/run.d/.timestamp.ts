1731647734 /servers/scratch50g/joshian/ALU_Project/gate_level_sim/slow_vdd1v0_basiccells.v
1731924947 /servers/scratch50g/joshian/ALU_Project/gate_level_sim/main_code_tb.v
1731928313 /servers/scratch50g/joshian/ALU_Project/gate_level_sim/ALU_test.v
1731646171 /servers/scratch50g/joshian/ALU_Project/gate_level_sim/ALU_netlist.v
